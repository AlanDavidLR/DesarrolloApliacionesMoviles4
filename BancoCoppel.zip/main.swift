import Foundation

var saldo: Double = 0.0
var primeraVez = true

func realizarDeposito() {
    print("Ingresa la cantidad a Depositar:")
    if let deposito = Double(readLine() ?? "0") {
        saldo += deposito
        print("Depósito exitoso.")
        print("Deseas realizar otro depósito? s/S n/N")
        if let respuesta = readLine()?.lowercased() {
            if respuesta == "s" {
                realizarDeposito()
            } else if respuesta == "n" {
                continuarOtraOperacion()
            } else {
                print("Respuesta no válida.")
                mostrarMenu()
            }
        }
    } else {
        print("Cantidad no válida. Por favor, ingresa un número.")
        realizarDeposito()
    }
}

func realizarRetiro() {
    if primeraVez {
        if saldo == 0 {
            print("No cuentas con saldo para realizar un retiro.")
            mostrarMenu()
        } else {
            print("Ingresa la cantidad a retirar:")
            if let retiro = Double(readLine() ?? "0") {
                if retiro <= saldo {
                    saldo -= retiro
                    print("Retiro exitoso.")
                } else {
                    print("No cuentas con el saldo suficiente para realizar este retiro.")
                }
                print("Deseas realizar otro retiro? s/S n/N")
                if let respuesta = readLine()?.lowercased() {
                    if respuesta == "s" {
                        realizarRetiro()
                    } else if respuesta == "n" {
                        continuarOtraOperacion()
                    } else {
                        print("Respuesta no válida.")
                        mostrarMenu()
                    }
                }
            } else {
                print("Cantidad no válida. Por favor, ingresa un número.")
                realizarRetiro()
            }
        }
    } else {
        print("Ingresa la cantidad a retirar:")
        if let retiro = Double(readLine() ?? "0") {
            if retiro <= saldo {
                saldo -= retiro
                print("Retiro exitoso.")
            } else {
                print("No cuentas con el saldo suficiente para realizar este retiro.")
            }
            print("Deseas realizar otro retiro? s/S n/N")
            if let respuesta = readLine()?.lowercased() {
                if respuesta == "s" {
                    realizarRetiro()
                } else if respuesta == "n" {
                    continuarOtraOperacion()
                } else {
                    print("Respuesta no válida.")
                    mostrarMenu()
                }
            }
        } else {
            print("Cantidad no válida. Por favor, ingresa un número.")
            realizarRetiro()
        }
    }
}

func consultarSaldo() {
    print("Tienes un saldo de: $\(saldo) pesos")
    print("Deseas continuar con otra operación? s/S n/N")
    if let respuesta = readLine()?.lowercased() {
        if respuesta == "s" {
            mostrarMenu()
        } else if respuesta == "n" {
            print("Cerrando sesión de cuenta, ¡vuelve pronto!")
        } else {
            print("Respuesta no válida.")
            continuarOtraOperacion()
        }
    }
}

func continuarOtraOperacion() {
    print("Deseas continuar con otra operación? s/S n/N")
    if let respuesta = readLine()?.lowercased() {
        if respuesta == "s" {
            mostrarMenu()
        } else if respuesta == "n" {
            print("Cerrando sesión de cuenta, ¡vuelve pronto!")
        } else {
            print("Respuesta no válida.")
            continuarOtraOperacion()
        }
    }
}

func mostrarMenu() {
    print("Banco Coppel")
    print("1. Depósito")
    print("2. Retiro")
    print("3. Saldo")
    print("4. Salir")
    print("Elige el número de la opción:")

    if let opcion = Int(readLine() ?? "0") {
        switch opcion {
        case 1:
            realizarDeposito()
        case 2:
            realizarRetiro()
        case 3:
            consultarSaldo()
        case 4:
            print("Cerrando sesión de cuenta, ¡vuelve pronto!")
        default:
            print("Opción no válida. Por favor, elige una opción del 1 al 4.")
            mostrarMenu()
        }
    } else {
        print("Opción no válida. Por favor, elige una opción del 1 al 4.")
        mostrarMenu()
    }
}

print("Bienvenido a la Banca en Línea del Banco Mexicano")
mostrarMenu()
