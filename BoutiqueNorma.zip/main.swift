import Foundation

struct Articulo {
    var nombre: String
    var precio: Double
    var stock: Int
}

var articulos: [Articulo] = [
    Articulo(nombre: "Zapatos", precio: 250.00, stock: 150),
    Articulo(nombre: "Playeras", precio: 100.00, stock: 700),
    Articulo(nombre: "Pantalones", precio: 200.00, stock: 20),
    Articulo(nombre: "Sombreros", precio: 300.00, stock: 100),

    Articulo(nombre: "Bufanda", precio: 50.00, stock: 30),
    Articulo(nombre: "Vestido", precio: 350.00, stock: 40),
    Articulo(nombre: "Chaqueta", precio: 150.00, stock: 60),
    Articulo(nombre: "Gafas de sol", precio: 80.00, stock: 120),
    Articulo(nombre: "Calcetines", precio: 5.00, stock: 500),
    Articulo(nombre: "Gorras", precio: 30.00, stock: 200)
]


func mostrarArticulos() {
    print("-----Articulos------")
    for (index, articulo) in articulos.enumerated() {
        print("Opcion: \(index + 1)")
        print("Articulo: \(articulo.nombre)")
        print("Precio: $\(articulo.precio)")
        print("Stock: \(articulo.stock)")
        print("------------------")
    }
}

func main() {
    var carrito: [Articulo] = []
    var totalPagar: Double = 0.0

    print("Bienvenido a la Boutique Norma")

    while true {
        mostrarArticulos()
        print("1. Comprar artículo")
        print("2. Salir")
        print("Seleccione una opción:")

        if let opcion = Int(readLine() ?? "0") {
            switch opcion {
            case 1:
                print("Ingrese el número de artículo a comprar:")
                if let articuloSeleccionado = Int(readLine() ?? "0"), articuloSeleccionado > 0, articuloSeleccionado <= articulos.count {
                    let indice = articuloSeleccionado - 1
                    let articulo = articulos[indice]

                    print("Ingrese la cantidad de artículos que desea comprar:")
                    if let cantidad = Int(readLine() ?? "0") {
                        if cantidad <= articulo.stock {
                            carrito.append(articulo)
                            totalPagar += Double(cantidad) * articulo.precio
                            articulos[indice].stock -= cantidad
                            print("-----------------")
                            print("Usted ha comprado \(cantidad) \(articulo.nombre) x \(cantidad)")
                            print("Total: $\(Double(cantidad) * articulo.precio)")
                            print("-----------------")
                        } else {
                            print("No hay suficiente stock, lo sentimos.")
                        }
                    }
                }
            case 2:
                print("Resumen de la compra:")
                for item in carrito {
                    print("Articulo: \(item.nombre) x \(carrito.filter({$0.nombre == item.nombre}).count)")
                }
                print("Total a pagar: $\(totalPagar)")
                print("Gracias por comprar en la Boutique Norma.")
                return
            default:
                break
            }
        }
    }
}

main()
